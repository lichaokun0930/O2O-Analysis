#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
商品场景智能打标引擎
================================================================================
为商品打上多维度场景标签,分析购买驱动和决策因素

核心功能:
1. 多维度场景识别 - 基础场景、季节场景、节假日场景、天气场景
2. 商品场景适配性分析 - 分析商品在各场景下的表现
3. 购买驱动分析 - 识别促使购买的核心因素
4. 下单决策分析 - 分析用户决策路径和影响因素

作者: AI Assistant
日期: 2025-10-26
"""

import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Tuple
import warnings
warnings.filterwarnings('ignore')


# ================================================================================
# 1. 扩展场景维度定义
# ================================================================================

class SceneDimensions:
    """多维度场景定义"""
    
    # 基础时段场景 (原有)
    BASE_SCENES = {
        '早餐': ['豆浆', '油条', '包子', '粥', '煎饼', '鸡蛋', '面包', '牛奶', '燕麦'],
        '午餐': ['便当', '盒饭', '套餐', '炒饭', '炒面', '拉面', '米饭'],
        '晚餐': ['晚饭', '炒菜', '烧烤'],
        '夜宵': ['宵夜', '串串', '小龙虾', '啤酒'],
        '下午茶': ['咖啡', '奶茶', '蛋糕', '甜品', '冰淇淋'],
        '休闲零食': ['薯片', '饼干', '糖果', '巧克力', '坚果', '果冻', '瓜子'],
        '日用补充': ['纸巾', '卫生纸', '洗衣液', '洗洁精', '牙膏', '香皂'],
        '应急购买': ['电池', '充电器', '雨伞', '口罩', '创可贴'],
        '营养补充': ['维生素', '蛋白粉', '钙片', '保健品'],
        '社交娱乐': ['红酒', '白酒', '香烟', '礼品']
    }
    
    # 季节场景 (新增)
    SEASON_SCENES = {
        '春季场景': {
            '时间范围': '3-5月',
            '商品关键词': ['踏青', '防晒', '润肤', '换季', '轻食', '绿茶', '花茶'],
            '特点': '万物复苏,轻装出行,重养生'
        },
        '夏季场景': {
            '时间范围': '6-8月',
            '商品关键词': ['冰淇淋', '冷饮', '防晒霜', '凉席', '电扇', '西瓜', '啤酒', '冰镇'],
            '特点': '高温炎热,重消暑,户外活动'
        },
        '秋季场景': {
            '时间范围': '9-11月',
            '商品关键词': ['润燥', '保湿', '热饮', '补品', '月饼', '大闸蟹', '养生'],
            '特点': '天气干燥,重滋补,贴秋膘'
        },
        '冬季场景': {
            '时间范围': '12-2月',
            '商品关键词': ['保暖', '热饮', '火锅', '羊肉', '暖宝宝', '姜茶', '滋补'],
            '特点': '寒冷低温,重保暖,热量补充'
        }
    }
    
    # 节假日场景 (新增)
    HOLIDAY_SCENES = {
        '春节场景': {
            '时间': '农历正月初一前后',
            '商品关键词': ['年货', '糖果', '坚果', '礼盒', '对联', '红包', '烟花'],
            '购买驱动': '团圆聚会、走亲访友、囤货',
            '决策特点': '大批量采购、重品牌、重包装'
        },
        '端午场景': {
            '时间': '农历五月初五',
            '商品关键词': ['粽子', '咸蛋', '雄黄酒'],
            '购买驱动': '传统习俗、节日氛围',
            '决策特点': '应景消费、临时性强'
        },
        '中秋场景': {
            '时间': '农历八月十五',
            '商品关键词': ['月饼', '大闸蟹', '礼盒', '水果'],
            '购买驱动': '送礼需求、家庭团聚',
            '决策特点': '重包装、重品牌、礼品属性强'
        },
        '双11场景': {
            '时间': '11月11日',
            '商品关键词': ['囤货', '促销', '预售'],
            '购买驱动': '价格优惠、囤货心理',
            '决策特点': '大批量、价格敏感、计划性强'
        },
        '618场景': {
            '时间': '6月18日',
            '商品关键词': ['促销', '满减', '折扣'],
            '购买驱动': '价格优惠',
            '决策特点': '价格驱动、冲动消费'
        },
        '周末场景': {
            '时间': '每周六日',
            '商品关键词': ['休闲', '聚会', '家庭装', '零食', '饮料'],
            '购买驱动': '居家休闲、家庭聚会',
            '决策特点': '批量购买、重享受'
        },
        '工作日场景': {
            '时间': '周一至周五',
            '商品关键词': ['速食', '便当', '提神', '办公'],
            '购买驱动': '快速便捷、效率优先',
            '决策特点': '小批量、即时消费'
        }
    }
    
    # 天气场景 (新增)
    WEATHER_SCENES = {
        '晴天场景': {
            '商品关键词': ['冷饮', '防晒', '户外', '运动饮料', '冰淇淋'],
            '购买驱动': '出行意愿强、户外活动',
            '决策特点': '冲动消费、即时需求'
        },
        '雨天场景': {
            '商品关键词': ['雨伞', '雨衣', '热饮', '方便面', '零食', '外卖'],
            '购买驱动': '居家避雨、应急需求',
            '决策特点': '便利性优先、懒人经济'
        },
        '高温场景': {
            '温度阈值': '>32°C',
            '商品关键词': ['冰淇淋', '冷饮', '冰镇', '防暑', '凉茶', '西瓜'],
            '购买驱动': '解暑降温、舒适需求',
            '决策特点': '即时消费、高频次'
        },
        '低温场景': {
            '温度阈值': '<10°C',
            '商品关键词': ['热饮', '姜茶', '火锅料', '暖宝宝', '保温杯'],
            '购买驱动': '御寒保暖、热量补充',
            '决策特点': '功能性强、刚需属性'
        }
    }
    
    # 特殊时段场景 (新增)
    SPECIAL_TIME_SCENES = {
        '开学季场景': {
            '时间': '8月底-9月初',
            '商品关键词': ['文具', '书包', '零食', '饮料', '方便食品'],
            '购买驱动': '新学期准备、学生需求',
            '决策特点': '集中采购、刚需'
        },
        '考试季场景': {
            '时间': '6月、12月',
            '商品关键词': ['提神', '咖啡', '功能饮料', '巧克力', '坚果'],
            '购买驱动': '备考压力、提神需求',
            '决策特点': '功能性强、高频复购'
        },
        '减肥季场景': {
            '时间': '春节后、夏季前',
            '商品关键词': ['低脂', '低卡', '代餐', '酸奶', '水果', '沙拉'],
            '购买驱动': '健康意识、身材管理',
            '决策特点': '健康导向、持续性强'
        },
        '运动场景': {
            '商品关键词': ['能量棒', '运动饮料', '蛋白粉', '电解质'],
            '购买驱动': '运动补给、体能恢复',
            '决策特点': '专业性强、品牌忠诚度高'
        }
    }


# ================================================================================
# 2. 购买驱动分析引擎
# ================================================================================

class PurchaseDriverAnalyzer:
    """购买驱动分析器"""
    
    # 购买驱动类型定义
    DRIVER_TYPES = {
        '价格驱动': {
            '触发条件': ['促销', '折扣', '满减', '优惠券', '特价', '秒杀'],
            '用户特征': '价格敏感型',
            '决策路径': '比价 → 计算优惠 → 囤货',
            '营销策略': '满减活动、买赠、会员折扣'
        },
        '场景驱动': {
            '触发条件': ['时段匹配', '场景匹配', '节假日'],
            '用户特征': '场景导向型',
            '决策路径': '需求识别 → 场景匹配 → 快速下单',
            '营销策略': '场景化推荐、套餐组合、时段促销'
        },
        '品质驱动': {
            '触发条件': ['品牌', '进口', '有机', '高端', '精选'],
            '用户特征': '品质追求型',
            '决策路径': '品牌认知 → 品质评估 → 忠诚复购',
            '营销策略': '品牌背书、品质认证、会员专享'
        },
        '便利驱动': {
            '触发条件': ['即时配送', '30分钟达', '楼下自提', '24小时'],
            '用户特征': '便利优先型',
            '决策路径': '急需 → 快速下单 → 不计成本',
            '营销策略': '极速达、应急套餐、即时推送'
        },
        '健康驱动': {
            '触发条件': ['低脂', '低糖', '无添加', '有机', '健康'],
            '用户特征': '健康意识型',
            '决策路径': '成分查看 → 营养对比 → 理性选择',
            '营销策略': '健康标签、营养成分、专家推荐'
        },
        '社交驱动': {
            '触发条件': ['礼盒', '送礼', '聚会', '分享装'],
            '用户特征': '社交活跃型',
            '决策路径': '社交需求 → 选择礼品 → 注重包装',
            '营销策略': '礼盒包装、定制服务、社交分享'
        },
        '尝鲜驱动': {
            '触发条件': ['新品', '限定', '网红', '爆款'],
            '用户特征': '尝鲜探索型',
            '决策路径': '发现新品 → 尝试体验 → 分享评价',
            '营销策略': '新品首发、限量销售、KOL推荐'
        },
        '囤货驱动': {
            '触发条件': ['家庭装', '大包装', '多件优惠', '保质期长'],
            '用户特征': '计划囤货型',
            '决策路径': '需求预判 → 批量采购 → 长期储备',
            '营销策略': '组合优惠、会员专享、满额包邮'
        }
    }
    
    @staticmethod
    def analyze_purchase_driver(row: pd.Series) -> Dict:
        """
        分析单条订单的购买驱动
        
        参数:
            row: 订单行数据
            
        返回:
            Dict: 购买驱动分析结果
        """
        product_name = str(row.get('商品名称', '')).lower()
        scene = str(row.get('场景', ''))
        timeslot = str(row.get('时段', ''))
        
        # 检测各种驱动因素
        drivers = []
        driver_scores = {}
        
        # 1. 价格驱动检测
        price_keywords = ['促销', '折扣', '满减', '优惠', '特价', '秒杀']
        if any(kw in product_name for kw in price_keywords):
            drivers.append('价格驱动')
            driver_scores['价格驱动'] = 0.9
        
        # 2. 场景驱动检测 (如果场景和时段匹配)
        if scene and timeslot:
            drivers.append('场景驱动')
            driver_scores['场景驱动'] = 0.8
        
        # 3. 品质驱动检测
        quality_keywords = ['品牌', '进口', '有机', '精选', '高端']
        if any(kw in product_name for kw in quality_keywords):
            drivers.append('品质驱动')
            driver_scores['品质驱动'] = 0.7
        
        # 4. 便利驱动检测
        if '应急' in scene or '凌晨' in timeslot or '深夜' in timeslot:
            drivers.append('便利驱动')
            driver_scores['便利驱动'] = 0.85
        
        # 5. 健康驱动检测
        health_keywords = ['低脂', '低糖', '无糖', '无添加', '健康', '养生']
        if any(kw in product_name for kw in health_keywords):
            drivers.append('健康驱动')
            driver_scores['健康驱动'] = 0.75
        
        # 6. 社交驱动检测
        social_keywords = ['礼盒', '礼品', '送礼', '聚会', '分享装']
        if any(kw in product_name for kw in social_keywords):
            drivers.append('社交驱动')
            driver_scores['社交驱动'] = 0.8
        
        # 7. 尝鲜驱动检测
        new_keywords = ['新品', '限定', '网红', '爆款', '首发']
        if any(kw in product_name for kw in new_keywords):
            drivers.append('尝鲜驱动')
            driver_scores['尝鲜驱动'] = 0.7
        
        # 8. 囤货驱动检测
        stock_keywords = ['家庭装', '大包装', '组合装', '整箱']
        if any(kw in product_name for kw in stock_keywords):
            drivers.append('囤货驱动')
            driver_scores['囤货驱动'] = 0.75
        
        # 如果没有明确驱动,默认为场景驱动
        if not drivers:
            drivers.append('场景驱动')
            driver_scores['场景驱动'] = 0.5
        
        # 返回主要驱动(得分最高的)
        primary_driver = max(driver_scores, key=driver_scores.get) if driver_scores else '场景驱动'
        
        return {
            '主要驱动': primary_driver,
            '所有驱动': ', '.join(drivers),
            '驱动得分': driver_scores.get(primary_driver, 0.5),
            '驱动数量': len(drivers)
        }


# ================================================================================
# 3. 商品场景智能打标引擎
# ================================================================================

class ProductSceneTagger:
    """商品场景智能打标引擎"""
    
    def __init__(self):
        self.scene_dims = SceneDimensions()
        self.driver_analyzer = PurchaseDriverAnalyzer()
    
    def tag_product_scenes(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        为商品打上多维度场景标签
        
        参数:
            df: 订单数据DataFrame
            
        返回:
            DataFrame: 添加场景标签的数据
        """
        df = df.copy()
        
        # 1. 添加基础时段场景 (如果没有)
        if '场景' not in df.columns:
            df['场景'] = df.apply(self._infer_base_scene, axis=1)
        
        # 2. 添加季节场景
        df['季节场景'] = df.apply(self._infer_season_scene, axis=1)
        
        # 3. 添加节假日场景
        df['节假日场景'] = df.apply(self._infer_holiday_scene, axis=1)
        
        # 4. 添加天气场景 (基于商品特征推断)
        df['天气场景'] = df.apply(self._infer_weather_scene, axis=1)
        
        # 5. 添加特殊时段场景
        df['特殊场景'] = df.apply(self._infer_special_scene, axis=1)
        
        # 6. 分析购买驱动
        driver_results = df.apply(self.driver_analyzer.analyze_purchase_driver, axis=1)
        df['购买驱动'] = driver_results.apply(lambda x: x['主要驱动'])
        df['所有驱动'] = driver_results.apply(lambda x: x['所有驱动'])
        df['驱动得分'] = driver_results.apply(lambda x: x['驱动得分'])
        
        # 7. 分析决策因素
        df['决策因素'] = df.apply(self._analyze_decision_factors, axis=1)
        
        return df
    
    def _infer_base_scene(self, row: pd.Series) -> str:
        """推断基础场景"""
        product_name = str(row.get('商品名称', '')).lower()
        
        for scene, keywords in self.scene_dims.BASE_SCENES.items():
            for keyword in keywords:
                if keyword in product_name:
                    return scene
        
        return '日常购物'
    
    def _infer_season_scene(self, row: pd.Series) -> str:
        """推断季节场景"""
        product_name = str(row.get('商品名称', '')).lower()
        
        # 检查日期字段
        date_col = None
        for col in ['日期', '下单时间', '订单日期']:
            if col in row.index and pd.notna(row.get(col)):
                date_col = col
                break
        
        if date_col:
            try:
                order_date = pd.to_datetime(row[date_col])
                month = order_date.month
                
                # 根据月份判断季节
                if 3 <= month <= 5:
                    season = '春季场景'
                elif 6 <= month <= 8:
                    season = '夏季场景'
                elif 9 <= month <= 11:
                    season = '秋季场景'
                else:
                    season = '冬季场景'
                
                # 验证商品是否匹配季节关键词
                season_info = self.scene_dims.SEASON_SCENES[season]
                for keyword in season_info['商品关键词']:
                    if keyword in product_name:
                        return season
                
                return season  # 返回基于时间的季节
            except:
                pass
        
        # 如果没有日期,基于商品关键词推断
        for season, info in self.scene_dims.SEASON_SCENES.items():
            for keyword in info['商品关键词']:
                if keyword in product_name:
                    return season
        
        return '全季节'
    
    def _infer_holiday_scene(self, row: pd.Series) -> str:
        """推断节假日场景"""
        product_name = str(row.get('商品名称', '')).lower()
        
        # 检查日期字段
        date_col = None
        for col in ['日期', '下单时间', '订单日期']:
            if col in row.index and pd.notna(row.get(col)):
                date_col = col
                break
        
        if date_col:
            try:
                order_date = pd.to_datetime(row[date_col])
                weekday = order_date.weekday()  # 0=Monday, 6=Sunday
                
                # 判断是否周末
                if weekday >= 5:
                    return '周末场景'
                else:
                    # 检查是否工作日
                    return '工作日场景'
            except:
                pass
        
        # 基于商品关键词推断节假日
        for holiday, info in self.scene_dims.HOLIDAY_SCENES.items():
            for keyword in info['商品关键词']:
                if keyword in product_name:
                    return holiday
        
        return '日常'
    
    def _infer_weather_scene(self, row: pd.Series) -> str:
        """推断天气场景 (基于商品特征)"""
        product_name = str(row.get('商品名称', '')).lower()
        
        for weather, info in self.scene_dims.WEATHER_SCENES.items():
            for keyword in info['商品关键词']:
                if keyword in product_name:
                    return weather
        
        return '常规天气'
    
    def _infer_special_scene(self, row: pd.Series) -> str:
        """推断特殊时段场景"""
        product_name = str(row.get('商品名称', '')).lower()
        
        for special, info in self.scene_dims.SPECIAL_TIME_SCENES.items():
            for keyword in info['商品关键词']:
                if keyword in product_name:
                    return special
        
        return '无'
    
    def _analyze_decision_factors(self, row: pd.Series) -> str:
        """分析下单决策因素"""
        factors = []
        
        # 1. 时间因素
        timeslot = str(row.get('时段', ''))
        if '应急' in timeslot or '凌晨' in timeslot:
            factors.append('时间紧迫')
        
        # 2. 价格因素
        if '价格驱动' in str(row.get('购买驱动', '')):
            factors.append('价格优惠')
        
        # 3. 品质因素
        if '品质驱动' in str(row.get('购买驱动', '')):
            factors.append('品质保障')
        
        # 4. 场景匹配
        if '场景驱动' in str(row.get('购买驱动', '')):
            factors.append('场景匹配')
        
        # 5. 便利性
        if '便利驱动' in str(row.get('购买驱动', '')):
            factors.append('即时便利')
        
        if not factors:
            factors.append('常规需求')
        
        return ' + '.join(factors)
    
    def generate_product_scene_profile(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        生成商品场景画像报告
        
        参数:
            df: 已打标的订单数据
            
        返回:
            DataFrame: 商品场景画像
        """
        # 按商品聚合分析
        product_profiles = []
        
        for product_name in df['商品名称'].unique():
            product_df = df[df['商品名称'] == product_name]
            
            # 统计各维度场景
            base_scenes = product_df['场景'].value_counts().to_dict()
            season_scenes = product_df['季节场景'].value_counts().to_dict()
            holiday_scenes = product_df['节假日场景'].value_counts().to_dict()
            weather_scenes = product_df['天气场景'].value_counts().to_dict()
            
            # 统计购买驱动
            drivers = product_df['购买驱动'].value_counts().to_dict()
            
            # 统计决策因素
            decisions = product_df['决策因素'].value_counts().to_dict()
            
            # 计算场景适配度得分
            scene_coverage = len(base_scenes)  # 覆盖的场景数
            total_orders = len(product_df)
            
            # 主要场景 (订单量最多的前3个)
            top_scenes = sorted(base_scenes.items(), key=lambda x: x[1], reverse=True)[:3]
            main_scenes = ', '.join([f"{s[0]}({s[1]}单)" for s in top_scenes])
            
            # 主要驱动
            main_driver = max(drivers, key=drivers.get) if drivers else '未知'
            
            # 主要决策因素
            main_decision = max(decisions, key=decisions.get) if decisions else '未知'
            
            product_profiles.append({
                '商品名称': product_name,
                '总订单量': total_orders,
                '场景覆盖数': scene_coverage,
                '主要场景': main_scenes,
                '主要季节': max(season_scenes, key=season_scenes.get) if season_scenes else '全季节',
                '主要节假日': max(holiday_scenes, key=holiday_scenes.get) if holiday_scenes else '日常',
                '主要天气': max(weather_scenes, key=weather_scenes.get) if weather_scenes else '常规',
                '购买驱动': main_driver,
                '决策因素': main_decision,
                '场景适配度': round(scene_coverage / 10 * 100, 1)  # 满分10个场景
            })
        
        return pd.DataFrame(product_profiles).sort_values('总订单量', ascending=False)


# ================================================================================
# 4. 场景营销建议生成器
# ================================================================================

class SceneMarketingAdvisor:
    """场景营销建议生成器"""
    
    @staticmethod
    def generate_marketing_advice(product_profile: pd.Series) -> Dict:
        """
        根据商品场景画像生成营销建议
        
        参数:
            product_profile: 商品场景画像数据行
            
        返回:
            Dict: 营销建议
        """
        advice = {
            '商品名称': product_profile['商品名称'],
            '场景定位': '',
            '推荐策略': [],
            '营销时机': [],
            '组合建议': []
        }
        
        # 1. 场景定位
        main_scenes = product_profile['主要场景']
        if '早餐' in main_scenes:
            advice['场景定位'] = '早餐刚需品'
            advice['推荐策略'].append('晨间时段推送')
            advice['营销时机'].append('6-9点高峰期')
            advice['组合建议'].append('与豆浆、油条组合套餐')
        elif '下午茶' in main_scenes:
            advice['场景定位'] = '下午茶热门'
            advice['推荐策略'].append('14-16点重点推广')
            advice['营销时机'].append('工作日下午')
            advice['组合建议'].append('与蛋糕、咖啡搭配')
        elif '夜宵' in main_scenes:
            advice['场景定位'] = '夜宵必备'
            advice['推荐策略'].append('深夜营销')
            advice['营销时机'].append('21点后推送')
            advice['组合建议'].append('与啤酒、烧烤组合')
        
        # 2. 根据购买驱动定制策略
        driver = product_profile['购买驱动']
        if driver == '价格驱动':
            advice['推荐策略'].append('满减活动、限时秒杀')
        elif driver == '品质驱动':
            advice['推荐策略'].append('品质认证、品牌背书')
        elif driver == '便利驱动':
            advice['推荐策略'].append('30分钟达、即时推送')
        elif driver == '健康驱动':
            advice['推荐策略'].append('健康标签、营养成分展示')
        
        # 3. 根据季节场景建议
        season = product_profile['主要季节']
        if season == '夏季场景':
            advice['营销时机'].append('6-8月重点推广')
        elif season == '冬季场景':
            advice['营销时机'].append('12-2月重点推广')
        
        # 4. 场景适配度评估
        adaptability = product_profile['场景适配度']
        if adaptability > 50:
            advice['推荐策略'].append('多场景营销，覆盖全时段')
        else:
            advice['推荐策略'].append('聚焦核心场景，精准营销')
        
        return advice


# ================================================================================
# 5. 主函数 - 快速使用
# ================================================================================

def smart_tag_products(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    一键为商品打标并生成场景画像
    
    参数:
        df: 订单数据DataFrame (必须包含: 商品名称, 日期/下单时间)
        
    返回:
        Tuple[DataFrame, DataFrame]: (打标后的订单数据, 商品场景画像)
    
    使用示例:
        >>> df = pd.read_excel('订单数据.xlsx')
        >>> tagged_df, profiles = smart_tag_products(df)
        >>> print(profiles.head(10))  # 查看Top10商品场景画像
    """
    print("🚀 商品场景智能打标引擎启动...")
    print("=" * 80)
    
    # 初始化打标引擎
    tagger = ProductSceneTagger()
    
    # 1. 为订单打标
    print("📊 步骤1/3: 为订单数据打上多维度场景标签...")
    tagged_df = tagger.tag_product_scenes(df)
    print(f"   ✅ 完成! 添加了 7 个场景维度标签")
    print(f"      - 基础场景: {tagged_df['场景'].nunique()} 种")
    print(f"      - 季节场景: {tagged_df['季节场景'].nunique()} 种")
    print(f"      - 节假日场景: {tagged_df['节假日场景'].nunique()} 种")
    print(f"      - 天气场景: {tagged_df['天气场景'].nunique()} 种")
    print(f"      - 购买驱动: {tagged_df['购买驱动'].nunique()} 种")
    
    # 2. 生成商品画像
    print("\n📈 步骤2/3: 生成商品场景适配性画像...")
    product_profiles = tagger.generate_product_scene_profile(tagged_df)
    print(f"   ✅ 完成! 生成 {len(product_profiles)} 个商品的场景画像")
    
    # 3. 生成营销建议
    print("\n💡 步骤3/3: 生成场景营销建议...")
    advisor = SceneMarketingAdvisor()
    marketing_advice = product_profiles.head(20).apply(
        advisor.generate_marketing_advice, axis=1
    ).tolist()
    print(f"   ✅ 完成! 为Top20商品生成营销建议")
    
    print("\n" + "=" * 80)
    print("✅ 商品场景智能打标完成!")
    print(f"\n📊 数据统计:")
    print(f"   - 订单总数: {len(tagged_df):,}")
    print(f"   - 商品总数: {tagged_df['商品名称'].nunique():,}")
    print(f"   - 场景覆盖: {tagged_df['场景'].nunique()} 个基础场景")
    print(f"   - 购买驱动: {tagged_df['购买驱动'].nunique()} 种驱动类型")
    
    return tagged_df, product_profiles


# ================================================================================
# 测试代码
# ================================================================================

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("商品场景智能打标引擎 - 测试模式")
    print("=" * 80)
    
    # 创建测试数据
    test_data = pd.DataFrame({
        '日期': pd.to_datetime([
            '2025-09-01 08:30:00',  # 早餐时段
            '2025-06-15 15:00:00',  # 夏季下午茶
            '2025-12-25 19:00:00',  # 冬季晚餐
            '2025-11-11 10:00:00',  # 双11囤货
            '2025-09-15 23:00:00',  # 中秋节夜宵
            '2025-09-01 14:30:00',  # 秋季下午茶
        ]),
        '商品名称': [
            '豆浆',
            '冰淇淋',
            '火锅底料',
            '薯片家庭装',
            '月饼礼盒',
            '低脂酸奶'
        ],
        '一级分类名': ['饮料', '冷饮', '速食', '休闲食品', '糕点', '乳制品'],
        '订单ID': ['001', '002', '003', '004', '005', '006']
    })
    
    print("\n📋 测试数据:")
    print(test_data[['商品名称', '日期']])
    
    # 执行智能打标
    tagged_df, profiles = smart_tag_products(test_data)
    
    print("\n\n📊 打标结果示例:")
    print(tagged_df[['商品名称', '场景', '季节场景', '节假日场景', '购买驱动', '决策因素']].to_string(index=False))
    
    print("\n\n🎯 商品场景画像:")
    print(profiles.to_string(index=False))
    
    print("\n✅ 测试完成!")
