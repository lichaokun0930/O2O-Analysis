#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
场景推断工具模块
智能推断消费场景和时段

优先级：
1. 商品名称关键词（最高优先级）
2. 分类映射
3. 时段后备方案
"""

import pandas as pd
import re
from datetime import datetime

# 场景关键词映射（商品名称优先）
SCENE_KEYWORDS = {
    '早餐': ['早餐', '豆浆', '油条', '包子', '粥', '煎饼', '鸡蛋', '面包', '牛奶', '燕麦'],
    '午餐': ['午餐', '便当', '盒饭', '套餐', '炒饭', '炒面', '拉面', '米饭'],
    '晚餐': ['晚餐', '晚饭', '炒菜', '烧烤'],
    '夜宵': ['夜宵', '宵夜', '烧烤', '串串', '小龙虾', '啤酒'],
    '下午茶': ['咖啡', '奶茶', '蛋糕', '甜品', '冰淇淋', '饮料'],
    '休闲零食': ['薯片', '饼干', '糖果', '巧克力', '坚果', '果冻', '瓜子'],
    '日用补充': ['纸巾', '卫生纸', '洗衣液', '洗洁精', '牙膏', '香皂', '洗发水'],
    '应急购买': ['电池', '充电器', '雨伞', '口罩', '创可贴'],
    '营养补充': ['维生素', '蛋白粉', '钙片', '保健品']
}

# 分类到场景的映射
CATEGORY_SCENE_MAP = {
    '休闲食品': '休闲零食',
    '饮料': '下午茶',
    '酒水': '夜间社交',
    '粮油调味': '日常购物',
    '速食': '午餐',
    '个人护理': '日用补充',
    '家庭清洁': '日用补充',
    '母婴': '居家消费',
    '宠物': '居家消费',
    '生鲜': '日常购物'
}

# 时段到场景的后备映射（修复：所有时段默认都是日常购物，避免场景被限制在特定时段）
TIMESLOT_SCENE_MAP = {
    '清晨(6-9点)': '日常购物',  # 修改：早餐应由商品名称关键词匹配
    '上午(9-12点)': '日常购物',
    '正午(12-14点)': '日常购物',  # 修改：午餐应由商品名称关键词匹配
    '下午(14-18点)': '日常购物',  # 修改：下午茶应由商品名称关键词匹配
    '傍晚(18-21点)': '日常购物',  # 修改：晚餐应由商品名称关键词匹配
    '晚间(21-24点)': '日常购物',  # 修改：休闲零食应由商品名称关键词匹配
    '深夜(0-3点)': '日常购物',    # 修改：夜宵应由商品名称关键词匹配
    '凌晨(3-6点)': '日常购物'     # 修改：应急购买应由商品名称关键词匹配
}


def classify_timeslot(hour):
    """
    根据小时数分类时段
    
    参数:
        hour: 小时数（0-23）
    
    返回:
        str: 时段标签
    """
    if pd.isna(hour):
        return '未知时段'
    
    hour = int(hour)
    
    if 6 <= hour < 9:
        return '清晨(6-9点)'
    elif 9 <= hour < 12:
        return '上午(9-12点)'
    elif 12 <= hour < 14:
        return '正午(12-14点)'
    elif 14 <= hour < 18:
        return '下午(14-18点)'
    elif 18 <= hour < 21:
        return '傍晚(18-21点)'
    elif 21 <= hour < 24:
        return '晚间(21-24点)'
    elif 0 <= hour < 3:
        return '深夜(0-3点)'
    else:  # 3-6点
        return '凌晨(3-6点)'


def infer_scene(row):
    """
    智能推断消费场景
    
    优先级:
    1. 商品名称关键词匹配（最准确）
    2. 分类映射
    3. 时段后备方案
    
    参数:
        row: DataFrame的一行，包含 '商品名称', '一级分类名', '时段' 字段
    
    返回:
        str: 场景标签
    """
    product_name = str(row.get('商品名称', ''))
    category = str(row.get('一级分类名', ''))
    timeslot = str(row.get('时段', ''))
    
    # 第1优先级：商品名称关键词匹配
    for scene, keywords in SCENE_KEYWORDS.items():
        for keyword in keywords:
            if keyword in product_name:
                return scene
    
    # 第2优先级：分类映射
    if category in CATEGORY_SCENE_MAP:
        return CATEGORY_SCENE_MAP[category]
    
    # 第3优先级：时段后备
    if timeslot in TIMESLOT_SCENE_MAP:
        return TIMESLOT_SCENE_MAP[timeslot]
    
    # 默认：社交娱乐（最通用的场景）
    return '社交娱乐'


def add_scene_and_timeslot_fields(df, use_advanced_tagger=True):
    """
    为DataFrame添加场景和时段字段
    
    参数:
        df: pandas DataFrame，必须包含 '日期' 或 '下单时间' 字段
        use_advanced_tagger: 是否使用高级智能打标引擎 (默认True)
    
    返回:
        DataFrame: 添加了 '时段' 和 '场景' 字段的DataFrame
    
    示例:
        >>> df = pd.DataFrame({'日期': ['2025-09-01 08:30:00'], '商品名称': ['豆浆']})
        >>> df = add_scene_and_timeslot_fields(df)
        >>> df[['时段', '场景']].values
        array([['清晨(6-9点)', '早餐']], dtype=object)
    """
    df = df.copy()
    
    # 确定日期列
    date_col = '日期' if '日期' in df.columns else '下单时间'
    
    if date_col not in df.columns:
        raise ValueError(f"DataFrame必须包含 '日期' 或 '下单时间' 字段")
    
    # 确保日期列是datetime类型
    if not pd.api.types.is_datetime64_any_dtype(df[date_col]):
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
    
    # 1. 添加时段字段 (总是执行)
    df['小时'] = df[date_col].dt.hour
    df['时段'] = df['小时'].apply(classify_timeslot)
    
    # 2. 添加场景字段
    if use_advanced_tagger:
        # 使用高级智能打标引擎 (多维度分析)
        try:
            from 商品场景智能打标引擎 import ProductSceneTagger
            print("   🎯 使用智能场景打标引擎...")
            tagger = ProductSceneTagger()
            
            # 先确保有基础场景字段,避免后续处理出错
            if '场景' not in df.columns:
                df['场景'] = df.apply(infer_scene, axis=1)
            
            # 执行智能打标
            df = tagger.tag_product_scenes(df)
            
            print(f"   ✅ 智能打标完成! 识别到 {df['场景'].nunique()} 个场景")
            if '购买驱动' in df.columns:
                print(f"      - 购买驱动: {df['购买驱动'].nunique()} 种")
            if '季节场景' in df.columns:
                print(f"      - 季节场景: {df['季节场景'].nunique()} 种")
        except ImportError:
            print("   ⚠️ 智能打标引擎不可用，降级到基础模式")
            df['场景'] = df.apply(infer_scene, axis=1)
        except Exception as e:
            print(f"   ⚠️ 智能打标引擎执行失败: {e}，降级到基础模式")
            import traceback
            traceback.print_exc()
            df['场景'] = df.apply(infer_scene, axis=1)
    else:
        # 使用基础关键词匹配
        print("   📋 使用基础场景推断...")
        df['场景'] = df.apply(infer_scene, axis=1)
    
    # 清理临时列
    df = df.drop(columns=['小时'], errors='ignore')
    
    return df


def get_available_scenes(df):
    """
    获取数据中所有可用的场景列表
    
    参数:
        df: DataFrame with '场景' column
    
    返回:
        list: 排序后的场景列表
    """
    if '场景' not in df.columns:
        return []
    
    return sorted(df['场景'].dropna().unique().tolist())


def get_available_timeslots(df):
    """
    获取数据中所有可用的时段列表
    
    参数:
        df: DataFrame with '时段' column
    
    返回:
        list: 按时间顺序排序的时段列表
    """
    if '时段' not in df.columns:
        return []
    
    timeslot_order = [
        '清晨(6-9点)', '上午(9-12点)', '正午(12-14点)', '下午(14-18点)',
        '傍晚(18-21点)', '晚间(21-24点)', '深夜(0-3点)', '凌晨(3-6点)'
    ]
    
    available = df['时段'].dropna().unique().tolist()
    
    # 按预定义顺序排序
    return [t for t in timeslot_order if t in available]


# 单元测试
if __name__ == "__main__":
    print("=" * 60)
    print("场景推断模块测试")
    print("=" * 60)
    
    # 测试数据
    test_data = pd.DataFrame({
        '日期': pd.to_datetime([
            '2025-09-01 08:30:00',
            '2025-09-01 12:30:00',
            '2025-09-01 15:00:00',
            '2025-09-01 19:00:00',
            '2025-09-01 23:00:00'
        ]),
        '商品名称': ['豆浆', '炒饭', '咖啡', '炒菜', '啤酒'],
        '一级分类名': ['饮料', '速食', '饮料', '生鲜', '酒水']
    })
    
    print("\n原始数据:")
    print(test_data)
    
    # 添加场景和时段
    result = add_scene_and_timeslot_fields(test_data)
    
    print("\n添加场景和时段后:")
    print(result[['商品名称', '时段', '场景']])
    
    # 获取可用场景和时段
    scenes = get_available_scenes(result)
    timeslots = get_available_timeslots(result)
    
    print(f"\n可用场景 ({len(scenes)}个): {scenes}")
    print(f"可用时段 ({len(timeslots)}个): {timeslots}")
    
    print("\n✅ 测试完成！")
