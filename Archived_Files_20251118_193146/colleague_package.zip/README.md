﻿# 鏅鸿兘闂ㄥ簵鐪嬫澘 - 鐙珛鐜閰嶇疆鍖?

## 馃摝 鍖呭惈鍐呭
- Python鏍稿績鏂囦欢
- database妯″潡
- 閰嶇疆鏂囦欢妯℃澘
- 浣跨敤鏂囨。

## 馃殌 瀹屾暣閰嶇疆姝ラ

### 绗?姝? 瀹夎PostgreSQL鏁版嵁搴?

**涓嬭浇瀹夎:**
1. 璁块棶: https://www.postgresql.org/download/windows/
2. 涓嬭浇骞跺畨瑁匬ostgreSQL 14鎴栨洿楂樼増鏈?
3. 瀹夎鏃惰浣忚缃殑瀵嗙爜(榛樿鐢ㄦ埛鍚嶆槸postgres)

**鍒涘缓鏁版嵁搴?**
```powershell
# 鎵撳紑PowerShell,杩愯:
psql -U postgres -c "CREATE DATABASE o2o_dashboard;"
```

### 绗?姝? 瑙ｅ帇鏂囦欢
灏嗘鍘嬬缉鍖呰В鍘嬪埌宸ヤ綔鐩綍

### 绗?姝? 鍒涘缓铏氭嫙鐜
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 绗?姝? 瀹夎渚濊禆
```powershell
pip install -r requirements.txt
```

### 绗?姝? 閰嶇疆鏁版嵁搴撹繛鎺?
```powershell
# 澶嶅埗閰嶇疆鏂囦欢妯℃澘
Copy-Item .env.example .env
```

**缂栬緫 .env 鏂囦欢,淇敼鏁版嵁搴撹繛鎺?**
```ini
# 浣跨敤浣犺嚜宸辩殑PostgreSQL瀵嗙爜
DATABASE_URL=postgresql://postgres:浣犵殑瀵嗙爜@localhost:5432/o2o_dashboard
```

**绀轰緥:**
- 濡傛灉浣犵殑PostgreSQL瀵嗙爜鏄?123456:
  ```
  DATABASE_URL=postgresql://postgres:123456@localhost:5432/o2o_dashboard
  ```

### 绗?姝? 娴嬭瘯鏁版嵁搴撹繛鎺?
```powershell
python database\connection.py
```

濡傛灉鐪嬪埌 [OK] Database connection successful! 灏辨垚鍔熶簡!

### 绗?姝? 鍚姩鐪嬫澘
```powershell
python 鏅鸿兘闂ㄥ簵鐪嬫澘_Dash鐗?py
```

鐒跺悗璁块棶: http://localhost:8050

## 馃摎 璇︾粏鏂囨。
- 鏁版嵁搴撻厤缃揩閫熸寚鍗?md - 鏁版嵁搴撻厤缃缁嗚鏄?
- README_Dash鐗堜娇鐢ㄦ寚鍗?md - 鐪嬫澘浣跨敤璇存槑
- 渚濊禆鍜岀幆澧冭鏄?md - 鐜瑕佹眰璇存槑

## 鉂?甯歌闂

### Q: 濡備綍瀹夎PostgreSQL?
A: 
1. 涓嬭浇: https://www.postgresql.org/download/windows/
2. 杩愯瀹夎绋嬪簭,涓€璺疦ext
3. 璁剧疆postgres鐢ㄦ埛瀵嗙爜(璁颁綇杩欎釜瀵嗙爜!)
4. 绔彛淇濇寔榛樿5432
5. 瀹夎瀹屾垚鍚?鍦ㄥ紑濮嬭彍鍗曟壘鍒癝QL Shell(psql)

### Q: 濡備綍鍒涘缓鏁版嵁搴?
A: 
```powershell
# 鏂规硶1: 浣跨敤psql鍛戒护
psql -U postgres -c "CREATE DATABASE o2o_dashboard;"

# 鏂规硶2: 浣跨敤pgAdmin鍥惧舰鐣岄潰
# 1. 鎵撳紑pgAdmin
# 2. 杩炴帴鍒癙ostgreSQL
# 3. 鍙抽敭Databases -> Create -> Database
# 4. 杈撳叆鍚嶇О: o2o_dashboard
```

### Q: 鎻愮ず妯″潡鎵句笉鍒?
A: 纭繚宸叉縺娲昏櫄鎷熺幆澧冨苟瀹夎浜嗘墍鏈変緷璧?
```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### Q: 鏁版嵁搴撹繛鎺ュけ璐?
A: 妫€鏌?
1. PostgreSQL鏈嶅姟鏄惁杩愯(鏈嶅姟鍚? postgresql-x64-14)
2. .env鏂囦欢涓殑瀵嗙爜鏄惁姝ｇ‘
3. 鏁版嵁搴搊2o_dashboard鏄惁宸插垱寤?

### Q: 娌℃湁鏁版嵁鎬庝箞鍔?
A: 
- 鐪嬫澘鏀寔閫氳繃鐣岄潰涓婁紶Excel鏁版嵁
- 鎴栬仈绯婚」鐩礋璐ｄ汉鑾峰彇绀轰緥鏁版嵁

### Q: 绔彛8050琚崰鐢?
A: 鍦?env涓慨鏀?
```ini
PORT=8051  # 鏀规垚鍏朵粬绔彛
```

## 馃摓 闇€瑕佸府鍔?
鑱旂郴椤圭洰璐熻矗浜?

---
鎵撳寘鏃堕棿: 2025-11-13 18:29:30
